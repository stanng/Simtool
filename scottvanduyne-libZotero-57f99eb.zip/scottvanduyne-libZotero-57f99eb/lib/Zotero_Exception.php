<?php
class Zotero_Exception extends Exception
{
    
}
?>